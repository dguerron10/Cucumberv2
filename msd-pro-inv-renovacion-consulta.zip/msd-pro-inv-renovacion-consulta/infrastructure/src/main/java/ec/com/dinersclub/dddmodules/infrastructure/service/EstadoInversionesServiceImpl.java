package ec.com.dinersclub.dddmodules.infrastructure.service;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

import ec.com.dinersclub.dddmodules.domain.model.DinBodyInversionesEntrada;
import ec.com.dinersclub.dddmodules.domain.model.DinBodyInversionesSalida;
import ec.com.dinersclub.dddmodules.domain.repository.IEstadoInversionesRepository;
import ec.com.dinersclub.dddmodules.infrastructure.model.DinBodyInversionesSalidaAuro;
import ec.com.dinersclub.dddmodules.infrastructure.repository.EstadoInversionesRepository;
import ec.com.dinersclub.dto.RequestRs;
import ec.com.dinersclub.dto.ResponseRs;
import ec.com.dinersclub.excepciones.MicroservicioError;
import ec.com.dinersclub.excepciones.interfaces.AbstractMsExcepcion;

@ApplicationScoped
public class EstadoInversionesServiceImpl implements IEstadoInversionesRepository {

	@Inject
	EstadoInversionesRepository estadoNotificacionRepository;

	@Override
	public ResponseRs<DinBodyInversionesSalida> consultarEstadoInversiones(
			RequestRs<DinBodyInversionesEntrada> entrada) throws AbstractMsExcepcion, IllegalAccessException {
		ResponseRs<DinBodyInversionesSalidaAuro> conectorAuroSalida = estadoNotificacionRepository.ejecutarAuro(entrada);
				if (!conectorAuroSalida.getDinError().getCodigo().equals("0000")) {
					throw new MicroservicioError(conectorAuroSalida.getDinError());
				}
		return this.armarRespuestaMs(conectorAuroSalida, entrada);	
	}


	
	private ResponseRs<DinBodyInversionesSalida> armarRespuestaMs(
			ResponseRs<DinBodyInversionesSalidaAuro> conectorAuroSalida, RequestRs<DinBodyInversionesEntrada> entrada)
			throws AbstractMsExcepcion {

		ResponseRs<DinBodyInversionesSalida> responseMs = new ResponseRs<>(entrada.getDinHeader());

		if (conectorAuroSalida.getDinBody().getCodigo().trim().equalsIgnoreCase("0")) {

			responseMs.getDinHeader().setHoraTransaccion(conectorAuroSalida.getDinError().getFecha());
			responseMs.setDinBody(this.setearDinBody(conectorAuroSalida));
			responseMs.setIDinError(conectorAuroSalida.getDinError());

		} else {

			throw new MicroservicioError(
					conectorAuroSalida.getDinBody().getCodigo().trim(),
					conectorAuroSalida.getDinError().getOrigen(),
					conectorAuroSalida.getDinBody().getMensaje(), "");
		}

		return responseMs;
	}
	
	private DinBodyInversionesSalida setearDinBody(ResponseRs<DinBodyInversionesSalidaAuro> conectorAuroSalida) {

        DinBodyInversionesSalida dinBodyResponse = new DinBodyInversionesSalida();
        dinBodyResponse.setCodigo(conectorAuroSalida.getDinBody().getCodigo());
        dinBodyResponse.setTipo(conectorAuroSalida.getDinBody().getTipo());
        dinBodyResponse.setMensaje(conectorAuroSalida.getDinBody().getMensaje()); 
        return dinBodyResponse;
    }
	

	
}
