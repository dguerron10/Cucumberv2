package ec.com.dinersclub.dddmodules.infrastructure.model;

public class HeaderAuro{


	private String aplicacionId;
	private String canalId;
	private String uuid;
	private String ip;
	private String fechaHoraTransaccion;
	
	public HeaderAuro() {}
	
	public HeaderAuro(String aplicacionId, String canalId, String uuid, String ip, String fechaHoraTransaccion) {

		this.aplicacionId = aplicacionId;
		this.canalId = canalId;
		this.uuid = uuid;
		this.ip = ip;
		this.fechaHoraTransaccion = fechaHoraTransaccion;
	}

	/**
	 * @return the aplicacionId
	 */
	public String getAplicacionId() {
		return aplicacionId;
	}

	/**
	 * @param aplicacionId the aplicacionId to set
	 */
	public void setAplicacionId(String aplicacionId) {
		this.aplicacionId = aplicacionId;
	}

	/**
	 * @return the canalId
	 */
	public String getCanalId() {
		return canalId;
	}

	/**
	 * @param canalId the canalId to set
	 */
	public void setCanalId(String canalId) {
		this.canalId = canalId;
	}

	/**
	 * @return the uuid
	 */
	public String getUuid() {
		return uuid;
	}

	/**
	 * @param uuid the uuid to set
	 */
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	/**
	 * @return the ip
	 */
	public String getIp() {
		return ip;
	}

	/**
	 * @param ip the ip to set
	 */
	public void setIp(String ip) {
		this.ip = ip;
	}

	/**
	 * @return the fechaHoraTransaccion
	 */
	public String getFechaHoraTransaccion() {
		return fechaHoraTransaccion;
	}

	/**
	 * @param fechaHoraTransaccion the fechaHoraTransaccion to set
	 */
	public void setFechaHoraTransaccion(String fechaHoraTransaccion) {
		this.fechaHoraTransaccion = fechaHoraTransaccion;
	}
	

}
