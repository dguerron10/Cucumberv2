package ec.com.dinersclub.dddmodules.infrastructure.model;

public class DinBodyInversionesEntradaAuro  {

	
	private BodyAuro body;
	private HeaderAuro header;
	
	public DinBodyInversionesEntradaAuro() {}
	
	public DinBodyInversionesEntradaAuro(BodyAuro body, HeaderAuro header) {

		this.body = body;
		this.header = header;
	}

	/**
	 * @return the body
	 */
	public BodyAuro getBody() {
		return body;
	}

	/**
	 * @param body the body to set
	 */
	public void setBody(BodyAuro body) {
		this.body = body;
	}

	/**
	 * @return the header
	 */
	public HeaderAuro getHeader() {
		return header;
	}

	/**
	 * @param header the header to set
	 */
	public void setHeader(HeaderAuro header) {
		this.header = header;
	}
	
	
	
}
