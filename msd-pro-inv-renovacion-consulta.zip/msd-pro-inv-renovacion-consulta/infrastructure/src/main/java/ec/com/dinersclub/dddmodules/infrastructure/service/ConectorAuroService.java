package ec.com.dinersclub.dddmodules.infrastructure.service;

import javax.annotation.security.PermitAll;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import ec.com.dinersclub.dddmodules.infrastructure.providers.AS400ProviderMapper;

@Path("/v1")
@RegisterProvider(value = AS400ProviderMapper.class, priority = 50)
@RegisterRestClient(configKey = "conectorRest-api")
public interface ConectorAuroService {

	@POST
	@PermitAll
	@Path("/rest/ejecutar")
	Response ejecutarAuro(String jsonIn);

}