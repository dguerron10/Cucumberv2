package ec.com.dinersclub.dddmodules.infrastructure.model;

public class BodyAuro  {

	
	private String IdBaseGenerada;
	private String FechaDesde;
	private String FechaHasta;
	private String MontoMinimo;
	private String MontoMaximo;
	
	public BodyAuro() {}

	/**
	 * @param idBaseGenerada
	 * @param fechaDesde
	 * @param fechaHasta
	 * @param montoMinimo
	 * @param montoMaximo
	 */
	public BodyAuro(String idBaseGenerada, String fechaDesde, String fechaHasta, String montoMinimo,
			String montoMaximo) {
		
		IdBaseGenerada = idBaseGenerada;
		FechaDesde = fechaDesde;
		FechaHasta = fechaHasta;
		MontoMinimo = montoMinimo;
		MontoMaximo = montoMaximo;
	}

	public String getIdBaseGenerada() {
		return IdBaseGenerada;
	}

	public void setIdBaseGenerada(String idBaseGenerada) {
		IdBaseGenerada = idBaseGenerada;
	}

	public String getFechaDesde() {
		return FechaDesde;
	}

	public void setFechaDesde(String fechaDesde) {
		FechaDesde = fechaDesde;
	}

	public String getFechaHasta() {
		return FechaHasta;
	}

	public void setFechaHasta(String fechaHasta) {
		FechaHasta = fechaHasta;
	}

	public String getMontoMinimo() {
		return MontoMinimo;
	}

	public void setMontoMinimo(String montoMinimo) {
		MontoMinimo = montoMinimo;
	}

	public String getMontoMaximo() {
		return MontoMaximo;
	}

	public void setMontoMaximo(String montoMaximo) {
		MontoMaximo = montoMaximo;
	}


}
