package ec.com.dinersclub.dddmodules.infrastructure.repository;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.core.Response;

import org.eclipse.microprofile.rest.client.inject.RestClient;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import ec.com.dinersclub.dddmodules.domain.model.Body;
import ec.com.dinersclub.dddmodules.domain.model.DinBodyInversionesEntrada;
import ec.com.dinersclub.dddmodules.domain.model.Header;
import ec.com.dinersclub.dddmodules.infrastructure.extensiones.ObjectExt;
import ec.com.dinersclub.dddmodules.infrastructure.model.BodyAuro;
import ec.com.dinersclub.dddmodules.infrastructure.model.DinBodyInversionesEntradaAuro;
import ec.com.dinersclub.dddmodules.infrastructure.model.DinBodyInversionesSalidaAuro;
import ec.com.dinersclub.dddmodules.infrastructure.model.HeaderAuro;
import ec.com.dinersclub.dddmodules.infrastructure.service.ConectorAuroService;
import ec.com.dinersclub.dto.FactoryRs;
import ec.com.dinersclub.dto.HeaderRs;
import ec.com.dinersclub.dto.RequestRs;
import ec.com.dinersclub.dto.ResponseRs;
import ec.com.dinersclub.excepciones.MicroservicioExcepcion;
import ec.com.dinersclub.excepciones.interfaces.AbstractMsExcepcion;

@ApplicationScoped
public class EstadoInversionesRepository {

	@Inject
	@RestClient
	ConectorAuroService conectorAuroService;

	

	ObjectMapper mapper;

	public EstadoInversionesRepository() {
		mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	}
//responseRS
	public ResponseRs<DinBodyInversionesSalidaAuro> ejecutarAuro(RequestRs<DinBodyInversionesEntrada> entrada)
			throws AbstractMsExcepcion {
		
		
		HeaderRs header = new FactoryRs().mapearDinHeader(entrada.getDinHeader());
		header.setAliasDominio("auro");
		header.setPath("Services.FirmaDigital/api/Auro/NotifirEstado");
		header.setMetodo("post");
		

		DinBodyInversionesEntradaAuro dinBodyAs = this.armarEntrada(entrada);
		RequestRs<DinBodyInversionesEntradaAuro> request = new RequestRs<>(header, dinBodyAs);

		Response respuesta = conectorAuroService.ejecutarAuro(ObjectExt.convertirObjetToString(request));

		return this.procesarRespuestaAuro(respuesta.readEntity(ObjectNode.class));

	}

	private ResponseRs<DinBodyInversionesSalidaAuro> procesarRespuestaAuro(ObjectNode respuetasAuro)
			throws AbstractMsExcepcion {

		try {
			ResponseRs<DinBodyInversionesSalidaAuro> response = mapper.readValue(respuetasAuro.toString(),
					new TypeReference<ResponseRs<DinBodyInversionesSalidaAuro>>() {
					});
			return response;
		} catch (JsonProcessingException e) {
			throw new MicroservicioExcepcion(e);
		}

	}

	private DinBodyInversionesEntradaAuro armarEntrada(RequestRs<DinBodyInversionesEntrada> entrada) {

		
		Body body = entrada.getDinBody().getDinBody();
		BodyAuro bodyAuro = new BodyAuro();
		bodyAuro.setIdBaseGenerada(body.getIdBaseGenerada());
		bodyAuro.setFechaDesde(body.getFechaDesde());
		bodyAuro.setFechaHasta(body.getFechaHasta());
		bodyAuro.setMontoMinimo(body.getMontoMinimo());
		bodyAuro.setMontoMaximo(body.getMontoMaximo());
		
		
		Header header = entrada.getDinBody().getDinHeader();
		HeaderAuro headerAuro = new HeaderAuro();
		headerAuro.setAplicacionId(header.getAplicacionId());
		headerAuro.setCanalId(header.getCanalId());
		headerAuro.setFechaHoraTransaccion(header.getFechaHoraTransaccion());
		headerAuro.setIp(header.getIp());
		headerAuro.setUuid(header.getUuid()); 		

		return new DinBodyInversionesEntradaAuro(bodyAuro, headerAuro);
	}

}
