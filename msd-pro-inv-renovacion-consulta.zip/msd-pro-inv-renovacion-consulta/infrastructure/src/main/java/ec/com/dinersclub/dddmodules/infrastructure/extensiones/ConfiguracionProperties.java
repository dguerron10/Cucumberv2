package ec.com.dinersclub.dddmodules.infrastructure.extensiones;

import javax.enterprise.context.RequestScoped;

import org.eclipse.microprofile.config.inject.ConfigProperty;

@RequestScoped
public class ConfiguracionProperties {

	@ConfigProperty(name = "llaves.criptograficas.canal.url")
	String pathLlavesCriptograficasCanal;

	@ConfigProperty(name = "llaves.criptograficas.aplicacion.canal.url")
	String pathLlavesCriptograficasAplicacionCanal;

	/**
	 * @return the pathLlavesCriptograficasCanal
	 */
	public String getPathLlavesCriptograficasCanal() {
		return pathLlavesCriptograficasCanal;
	}

	/**
	 * @return the pathLlavesCriptograficasAplicacionCanal
	 */
	public String getPathLlavesCriptograficasAplicacionCanal() {
		return pathLlavesCriptograficasAplicacionCanal;
	}

}
