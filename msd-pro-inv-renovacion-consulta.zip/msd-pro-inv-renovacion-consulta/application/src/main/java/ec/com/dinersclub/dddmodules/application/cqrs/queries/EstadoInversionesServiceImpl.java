package ec.com.dinersclub.dddmodules.application.cqrs.queries;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

import ec.com.dinersclub.dddmodules.domain.model.DinBodyInversionesEntrada;
import ec.com.dinersclub.dddmodules.domain.model.DinBodyInversionesSalida;
import ec.com.dinersclub.dddmodules.domain.repository.IEstadoInversionesRepository;
import ec.com.dinersclub.dto.RequestRs;
import ec.com.dinersclub.dto.ResponseRs;
import ec.com.dinersclub.excepciones.interfaces.AbstractMsExcepcion;
import ec.com.dinersclub.validador.violation.SimpleValidator;

@ApplicationScoped
public class EstadoInversionesServiceImpl implements IEstadoInversionesService {

	@Inject
	IEstadoInversionesRepository iEstadoInversionesRepository;

	@Inject
	SimpleValidator simpleValidator;

	@Override
	public ResponseRs<DinBodyInversionesSalida> consultarEstadoInversiones(
			RequestRs<DinBodyInversionesEntrada> entrada) throws AbstractMsExcepcion, IllegalAccessException {
		simpleValidator.ejecutar(entrada);
		return iEstadoInversionesRepository.consultarEstadoInversiones(entrada);
	}

	



}
