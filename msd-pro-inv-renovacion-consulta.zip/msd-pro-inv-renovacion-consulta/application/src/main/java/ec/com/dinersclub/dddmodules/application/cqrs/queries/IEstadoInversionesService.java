package ec.com.dinersclub.dddmodules.application.cqrs.queries;

import ec.com.dinersclub.dddmodules.domain.model.DinBodyInversionesEntrada;
import ec.com.dinersclub.dddmodules.domain.model.DinBodyInversionesSalida;
import ec.com.dinersclub.dto.RequestRs;
import ec.com.dinersclub.dto.ResponseRs;
import ec.com.dinersclub.excepciones.interfaces.AbstractMsExcepcion;

/**
 * 
 * @author nDeveloper
 *
 */
public interface IEstadoInversionesService {

	ResponseRs<DinBodyInversionesSalida> consultarEstadoInversiones(RequestRs<DinBodyInversionesEntrada> entrada)
			throws AbstractMsExcepcion, IllegalAccessException;

}
