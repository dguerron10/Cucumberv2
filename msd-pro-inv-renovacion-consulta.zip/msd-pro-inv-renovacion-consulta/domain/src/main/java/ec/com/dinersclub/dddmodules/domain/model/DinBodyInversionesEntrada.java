package ec.com.dinersclub.dddmodules.domain.model;

import java.io.Serializable;

import io.quarkus.runtime.annotations.RegisterForReflection;

@RegisterForReflection
public class DinBodyInversionesEntrada  implements Serializable{

	private static final long serialVersionUID = 1L;
	private Body dinBody;
	private Header dinHeader;
	
	public DinBodyInversionesEntrada() {
		super ();
		this.dinBody = new Body();
		this.dinHeader = new Header();
	}		
	public Body getDinBody() {
		return dinBody;
	}
	public void setDinBody(Body dinBody) {
		this.dinBody = dinBody;
	}
	public Header getDinHeader() {
		return dinHeader;
	}
	public void setDinHeader(Header dinHeader) {
		this.dinHeader = dinHeader;
	}	
	
}
