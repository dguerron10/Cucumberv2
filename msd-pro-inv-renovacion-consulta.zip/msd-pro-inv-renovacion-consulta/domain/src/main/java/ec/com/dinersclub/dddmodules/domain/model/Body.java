package ec.com.dinersclub.dddmodules.domain.model;

import java.io.Serializable;

import io.quarkus.runtime.annotations.RegisterForReflection;

@RegisterForReflection
public class Body  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String IdBaseGenerada;
	private String FechaDesde;
	private String FechaHasta;
	private String MontoMinimo;
	private String MontoMaximo;
	
	
	
	public String getIdBaseGenerada() {
		return IdBaseGenerada;
	}
	public void setIdBaseGenerada(String idBaseGenerada) {
		IdBaseGenerada = idBaseGenerada;
	}
	public String getFechaDesde() {
		return FechaDesde;
	}
	public void setFechaDesde(String fechaDesde) {
		FechaDesde = fechaDesde;
	}
	public String getFechaHasta() {
		return FechaHasta;
	}
	public void setFechaHasta(String fechaHasta) {
		FechaHasta = fechaHasta;
	}
	public String getMontoMinimo() {
		return MontoMinimo;
	}
	public void setMontoMinimo(String montoMinimo) {
		MontoMinimo = montoMinimo;
	}
	public String getMontoMaximo() {
		return MontoMaximo;
	}
	public void setMontoMaximo(String montoMaximo) {
		MontoMaximo = montoMaximo;
	}
	
}
