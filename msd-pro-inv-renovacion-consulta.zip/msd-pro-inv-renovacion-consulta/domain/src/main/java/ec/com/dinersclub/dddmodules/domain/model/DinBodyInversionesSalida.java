package ec.com.dinersclub.dddmodules.domain.model;

import java.io.Serializable;

import io.quarkus.runtime.annotations.RegisterForReflection;

@RegisterForReflection
public class DinBodyInversionesSalida  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String Fecha;
	private String Tipo;
	private String Origen;
	private String Codigo;
	private String Mensaje;
	private String Detalle;
	
	
	public DinBodyInversionesSalida() {
		super();
	}


	public DinBodyInversionesSalida(String fecha, String tipo, String origen, String codigo, String mensaje,
			String detalle) {
		super();
		Fecha = fecha;
		Tipo = tipo;
		Origen = origen;
		Codigo = codigo;
		Mensaje = mensaje;
		Detalle = detalle;
	}


	/**
	 * @return the fecha
	 */
	public String getFecha() {
		return Fecha;
	}


	/**
	 * @param fecha the fecha to set
	 */
	public void setFecha(String fecha) {
		Fecha = fecha;
	}


	/**
	 * @return the tipo
	 */
	public String getTipo() {
		return Tipo;
	}


	/**
	 * @param tipo the tipo to set
	 */
	public void setTipo(String tipo) {
		Tipo = tipo;
	}


	/**
	 * @return the origen
	 */
	public String getOrigen() {
		return Origen;
	}


	/**
	 * @param origen the origen to set
	 */
	public void setOrigen(String origen) {
		Origen = origen;
	}


	/**
	 * @return the codigo
	 */
	public String getCodigo() {
		return Codigo;
	}


	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(String codigo) {
		Codigo = codigo;
	}


	/**
	 * @return the mensaje
	 */
	public String getMensaje() {
		return Mensaje;
	}


	/**
	 * @param mensaje the mensaje to set
	 */
	public void setMensaje(String mensaje) {
		Mensaje = mensaje;
	}


	/**
	 * @return the detalle
	 */
	public String getDetalle() {
		return Detalle;
	}


	/**
	 * @param detalle the detalle to set
	 */
	public void setDetalle(String detalle) {
		Detalle = detalle;
	}

	
}
