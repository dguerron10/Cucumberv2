package ec.com.dinersclub.encriptacion;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.io.IOUtils;

import ec.com.dinersclub.util.Base64;


public class Encriptacion {

	public static String getSimetric() {
		byte[] aesKey = { 0 };

		try {
			InputStream privateKeyStream = Encriptacion.class.getResourceAsStream("PrivateKeyPichincha.key");
			String idLlave = new String(IOUtils.toByteArray(privateKeyStream));
			PrivateKey pk = getLlavePrivada(idLlave);
			Cipher pkCipher;
			InputStream symetricKeyStream = Encriptacion.class.getResourceAsStream("llaveSimetrica.key");
			pkCipher = Cipher.getInstance("RSA");
			pkCipher.init(Cipher.DECRYPT_MODE, pk);
			byte[] datosDecifrados = pkCipher.doFinal(Base64.decode(IOUtils.toByteArray(symetricKeyStream)));
			aesKey = new byte[256 / 8];
			aesKey = datosDecifrados;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return new String(aesKey);
		
		
		
	}

	public static String getSimetric(String privateKey, String simetricKey ) {
		byte[] aesKey = { 0 };

		try {
			PrivateKey pk = getLlavePrivada(privateKey);
			Cipher pkCipher;
			InputStream symetricKeyStream = new ByteArrayInputStream(simetricKey.getBytes());
			pkCipher = Cipher.getInstance("RSA");
			pkCipher.init(Cipher.DECRYPT_MODE, pk);
			byte[] datosDecifrados = pkCipher.doFinal(Base64.decode(IOUtils.toByteArray(symetricKeyStream)));
			aesKey = new byte[256 / 8];
			aesKey = datosDecifrados;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return new String(aesKey);
	}
	
	
	public static String desencriptacionPichincha(String dato, String privateKey, String simetricKey) throws IOException {
		try {
			Cipher cipher = Cipher.getInstance("AES");
			cipher.init(2, new SecretKeySpec(getSimetric(privateKey,simetricKey).getBytes(), "AES"));
			return new String(cipher.doFinal(Base64.decode(dato)));
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			e.printStackTrace();
		} catch (BadPaddingException e) {
			e.printStackTrace();
		}
		return "";
	}

	public static String desencriptacionPichincha(String dato) throws IOException {
		try {
			Cipher cipher = Cipher.getInstance("AES");
			cipher.init(2, new SecretKeySpec(getSimetric().getBytes(), "AES"));
			return new String(cipher.doFinal(Base64.decode(dato)));
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			e.printStackTrace();
		} catch (BadPaddingException e) {
			e.printStackTrace();
		}
		return "";
	}
	
	
	private static PrivateKey getLlavePrivada(String llavePrivada) {

		PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(Base64.decode(llavePrivada));

		KeyFactory kf;

		try {
			kf = KeyFactory.getInstance("RSA");
			return kf.generatePrivate(spec);

		} catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
			e.printStackTrace();
		}

		return null;
	}
	
	public static String encriptacionPichincha(String dato, String privateKey, String simetricKey) throws IOException {
		String datoCifrado = "";
		
		try {
			Cipher cipher = null;
			SecretKeySpec key = new SecretKeySpec(getSimetric(privateKey,simetricKey).getBytes(), "AES");			
			cipher = Cipher.getInstance("AES");
			cipher.init(Cipher.ENCRYPT_MODE, key);
			byte[] campoCifrado = cipher.doFinal(dato.getBytes());
			datoCifrado = Base64.encode(campoCifrado);		 
		} catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException e) {
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			e.printStackTrace();
		} catch (BadPaddingException e) {
			e.printStackTrace();
		}
		 
		return datoCifrado;
	}
	
	public static String encriptacionPichincha(String dato) throws IOException {
		String datoCifrado = "";
		
		try {
			Cipher cipher = null;
			SecretKeySpec key = new SecretKeySpec(getSimetric().getBytes(), "AES");			
			cipher = Cipher.getInstance("AES");
			cipher.init(Cipher.ENCRYPT_MODE, key);
			byte[] campoCifrado = cipher.doFinal(dato.getBytes());
			datoCifrado = Base64.encode(campoCifrado);		 
		} catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException e) {
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			e.printStackTrace();
		} catch (BadPaddingException e) {
			e.printStackTrace();
		}
		 
		return datoCifrado;
	}
}