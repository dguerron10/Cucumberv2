package ec.com.dinersclub.encriptacion;

public class EncriptacionTest {

	public static void main(String[] args) {
		try {
			
			if(args.length > 0) {
				String datos = Encriptacion.desencriptacionPichincha(args[0]);
				System.out.println(datos);
			}
			else {
				//String encriptacion = encriptacionPichincha("423");
				//String encriptacion = desencriptacionPichincha("2plXTWa2Xn6ZlaU2SA6Ckw==");
				//System.out.println(encriptacion);
				String datos = Encriptacion.desencriptacionPichincha("2plXTWa2Xn6ZlaU2SA6Ckw==");
				System.out.println("opcion 1: "+datos);
				
				String datos1 = Encriptacion.desencriptacionPichincha("2plXTWa2Xn6ZlaU2SA6Ckw==",
						"MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDtFQozf8omvVR+7zMl0Rplm2"
						+ "aU9YsHpotKE1qj4F3r/Q2Xz9o7FcxOawl2kwYVyd/b95CDeu9khyfb09MRhVimLC2LTmvN7Sd"
						+ "iioHfs0cUBqmpQGNQTIGjn2X+xIGaFeS2Epy5gCxjsBR8UqbjbWtvskJFHUCf1G9XvDO7BJk77"
						+ "t9SK9Ma6wR/9XoKs4q//UED0vf5gnSYj+heWGRYvXzuAX7hgorhVmsMXE/5OBMhhi2h8dVhPUAw"
						+ "4azqIhY0maqvid7SO2pSQk2CJbk1mkSbC3FyNLz8EOMH7UBFTENWNxn9hVJrCbjEthWTmJ9AA+p"
						+ "d/doH6zbjSswO3IkUSXqtAgMBAAECggEBAMaJkgtifoVGk9XgtnJ606I3KwafQZhcjdSwtHz7zW"
						+ "tsdM+nDlfgf0FEPZ6ArN3eOotYnDqe3o7O6EAc+Wp4wq4V3OYF/B1s9kh9ORl+Zo2MrtO/yetaxk"
						+ "2hlKZvJSFGKEuY9ooZnhK1R9J83Kkj3o6hNwHt50pxefR89M0uoqweV1VJH6wp4U2LXHzUHIcWt37"
						+ "GLMDzaMvdQgiKD6Wx0/71tQBEHMKYm65PT0W3Z15THMnhuANloIVo1nwieWLlYyulb7OnPZJGdRIJ"
						+ "rhKUMlcs8uhhnkhx9oRUvcAFViHrHn6wO4JuqcrhS7X6Zn6eCLE1RhQBpBy7vsfDCyeRM3kCgYEA+m"
						+ "ieY81jqv/qDxC9cqAwA9jboq9iMn6ONo0WhjfBOONYnFZr8tiKczyKo8UfbkysDygnQRy7GYPTMgE30"
						+ "8bY0jAo1TQov30795MF6h3KvN7I51tBTK5FwkgdyHCD02aOFpUKiWvgk14V+5qwtKwd1rI27JBCoj4Oq"
						+ "OSKyxwWLMsCgYEA8mA+m9MdQI6MWvUbfQDqpDz5DUqlzjgEoj0etvnJdf7NxbwzaB3kjuk6FgJqZitLF"
						+ "HrJhCHjx9J4Ifrxmo3tAALG1Jq6jFZo9Osb9wBwo7wmup0LiF0EdcrBxcgZgafWwuXz5QlzLksskSoR3"
						+ "fqLX4eNY5Yqf0oUtJu+T1eWv2cCgYBOE2SfVaDn5ldCT0Pig5O0/16sAOcrO054L9GAE85JQImWZVPPKj"
						+ "kw6QWJPqMoLvvO1gQ3RxAHSpUFGGAhxfRAxQdWQqcZ3aBe9xZ3Asb90LDvggKAOC5D/1xZ7MsNlQJkhB/+7"
						+ "QXerQ1Jn9fM3YWINZTueaRtFdBYVLn5zk4TtQKBgB7gjflR+s8Hme/Ye+j/3eSQc/XyhY7w6f41JR2QUs76"
						+ "aAKByFbCQCTIp4K4Sg+8AjOYtOVlX9xL/svtaSwUWpX+xI+/KnbIZ1SUQxrDbpYdWR269gYoO3I6I1dr93vi"
						+ "AuUPYHPUMV07bHEN1/rceTbxUNzX+4/9wweDM8pt0SGPAoGBAOxaRpQsR/cXvG5S6QB8Dl7EvIa1ZCPqmQH6x"
						+ "NdkjoXmm68sbwcSpRL/7x1qQ9u7Q7AdZgUmPK5rKlcaWV/6MqOS5oWNZw2A461bmk/TZUk+M2Pb32fOqCPR8Dx"
						+ "ZmKRUQm4CGpy0ap9efqOznaD5OV1XIGUukJprPyNLK8C0B7xE",
						"4Iy+ulVkMi7tSH+12cmvYg1FvikZ9pszNLAUjlw2kInGmgQ4hxgCPcrky+baJJg82AZRS9iNEGjSjDIXrBcBHq2uZ"
						+ "Nv14Rib40SC7LWlDIafCsECR5zBZ81BYf7+pT5835Z2cFBgf9YRriyw7i1CHMoN2JbL8DsCs2FBr0U7aJXiUX2jC"
						+ "8vXPyMt/HP7blcGcSf2t4pajUt4+Y8OYTeulJUWmOxSUVSqulfSUNJIk6HFIa5yzahe3Q2+UODRj1bkYO6U4bwlhW"
						+ "wAeLFGLic0U/ghwmoe4pZaUqwYW5E7Wn9baK2LPNIb72jw17K7pub6VRyMjGZCJIdsxTC17nr0+g==");
				System.out.println("opcion 2: "+datos1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
